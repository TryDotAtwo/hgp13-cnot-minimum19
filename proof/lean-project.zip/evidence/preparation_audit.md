# Preparation audit, 27 September 2026

Scope: the explicit labelled 13-by-13 binary matrix in `matrix.tex`, all
156 directed CNOT gates at unit cost, no ancillas or free permutations.
This is an audit of the requested manuscript and evidence package, not a
claim that the unconditional lower bound was replayed by the Lean kernel.

| Requirement | Current evidence | Boundary |
|---|---|---|
| Exact target and upper bound | `main.tex`, `matrix.tex`, and the explicit 19-gate witness checked in `HGP13.lean` and `hgp13_verify.cpp` | Applies to the printed matrix only. |
| General reduction and abstract search | `claim_map.json`, `lean/FullWordPath.lean`, `lean/DepthFrontier.lean`, `lean/StateHistoryCost.lean`, `lean/FiniteFrontierBoundary.lean`; `verify_lean.py` audited 21,770 named declarations with only the allowed transitive axioms | The concrete finite premise is external; `NoShortProgram` without it remains open in Lean. |
| Concrete catalogue data | `scripts/independent_catalogue_check.cpp` independently enumerated all triples and quadruples; its four sorted key sets equal the pinned C++ export and the literal Lean-tree key sets (`independent_catalogue_audit.json`, `full_run_audit.json`) | This is an exhaustive external enumeration, not a kernel certificate of the concrete tables. |
| C++/Lean correspondence | `cpp_algorithm_audit.md` and `cpp_refinement_audit.md`; all 363 first-layer state sets agree, and every layer agrees for sectors 234 and 359; 1,518 terminal-cost differential trials agree with a BFS oracle | Static audit and bounded differential checks do not formally verify C++ semantics for every sector. |
| Full finite execution and source binding | `full_provenance_2026-09-27/provenance.txt` records source SHA-256 `2174f445df534455c30e9ae7b54b8dfff4fdbdce3ff4eaf6b7d7e557fa3f8e4c`, binary SHA-256 `2a80bbddffc1bfc70774405098164976effc8fbdde509522a2081bbd4ee4a1a1`, GCC 11.4.0 command, exit code 0, and new transcript hash; `audit.json` checks all 363 cases, 306,922,994 labels, 90,516 terminals, and exact agreement with the preserved run | Repeats the same implementation; the wrapper is not a signed binary attestation or independent solver. |
| Conditional theorem and trust statement | `ConcreteFiniteBoundary.exact_minimum_of_external_finite_result` fixes the literal lookup tables and derives `ExactMinimum target 19` from exact prefix completeness and no cheap state in any abstract frontier; the article and `STATUS.md` state this boundary | No unconditional kernel theorem is claimed. |
| Manuscript and delivery files | Two-pass `main.pdf` build: 22 pages, eight vector figures, embedded current Lean source ZIP, no undefined references or overfull boxes (`paper_build.json`). The source TAR and reproducibility ZIP contain the current proof, verifier, commands, run and audit; `SHA256.json` covers 260 files | The draft has not been submitted or distributed. Recompiling TeX alone does not recreate the PDF attachment; the same files are included separately as ancillary sources. |
| Prior art and benchmark identity | `prior_art_audit.md` and the paper distinguish prior 19-gate constructions, the unrestricted diameter, and the printed matrix | No global priority claim or identity with an external HGP benchmark is asserted. |

The full kernel replay of all sectors, a formal C++ refinement theorem, and
an unconditional Lean proof of the 19-CNOT minimum are outside the agreed
scope. The external finite calculation and its trust boundary remain
explicit in the paper and the claim register. No arXiv upload or outreach
has been performed.
